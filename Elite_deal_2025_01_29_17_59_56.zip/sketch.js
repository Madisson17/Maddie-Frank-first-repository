function setup() {
  createCanvas(400, 400);
}

function draw() {
  background('lightblue');
  
  //draw fish
  fill('orange');
  triangle(190, 75, 150, 50, 150, 90)
  ellipse(225, 75, 100, 55)  
  fill('red');
  triangle(80, 240, 150, 230, 125, 175)
  ellipse(170, 230,75,45)
  fill('white');
  ellipse(180, 220, 13, 13)
  ellipse(250, 65, 15, 15)
  fill('black');
  ellipse( 250, 67, 10, 10)
  ellipse( 181, 219, 7, 7)
  fill('tan');
 rect(0, 330, 400)
 
  
}